let phoneData = {
   name: 'Sascha',
   birthday: 08031986,
   phone: 98747894,
  // phone: 22558899,
   price: 39
}

function checkNumber(data){
    let regEx = /d/;
    let buff = [];
    if(data.phone !== data.birthday){
        for(i=0;i<data.phone.length;i++){
            if(data.phone[i] == data.phone[0]){
                buff[0].push(data.phone[i])}
            else if(data.phone[i] == data.phone[1]){
                buff[1].push(data.phone[i])}
            else if(data.phone[i] == data.phone[1]){
                buff[2].push(data.phone[i])}
            else if(data.phone[i] == data.phone[1]){
                buff[3].push(data.phone[i])}
        }
    }else{
        data.price += 200
    }

}

let result = checkNumber(phoneData);
console.log(result)

// Starttime = 09:30 Ending Time 11:15