function createTable (){
    const body = document.querySelector('body')
    document.createElement('h1');
    const table = document.createElement('table');
    const tblBody = document.createElement('tbody');
    
    //cells creation first Tablerow
    for (let i=0;i<5;i++){
        const row = document.createElement('tr')
        
        //table cells and Textnode
        for(let j=0;j<3;j++){
            const cell = document.createElement('td')
            const cellText = document.createTextNode('containerRow-' + i + ' cell-'+j)
            row.appendChild(cell)
            cell.id=(i+''+j)
            cell.appendChild(cellText)
        }
        tblBody.appendChild(row)
    }
    //append the <tbody> inside the <table>
    table.appendChild(tblBody)

    //put the table inside the <body>
    body.appendChild(table);
    // adding the border attribute to table
    table.setAttribute('border', '3')

};

createTable()